﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CamController : MonoBehaviour
{
    public Transform player;

    Vector3 offset;
    Vector3 target;

    void Start()
    {
        offset = transform.position - player.position;
    }

    void Update()
    {
        target = player.position + offset;
        target.x = Mathf.Clamp(target.x, -29, 29);
        transform.position = target;
    }
}
