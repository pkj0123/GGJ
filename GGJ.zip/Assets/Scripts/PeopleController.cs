﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PeopleController : MonoBehaviour
{
    public float movementSpeed;
    public Vector2 walkableRange;
    public Vector2 distanceIncrement;
    public Vector2 waitTimeRange;
    public GameObject exclamationMarkIcon;
    public Transform exclamationMarkPos;
    public Slider fearSlider;
    public float fearRate;

    //Rigidbody2D rb;
    Animator anim;
    Collider2D col;
    Direction dir;
    Vector3 target;
    float generatedIncrement;
    float generatedWaitTime;
    float waitedTime;
    bool isScared = false;
    Vector2 startColOffset;
    GameController gameController;
    
    enum Direction
    {
        Left,
        Right
    }

    private void Start()
    {
        //rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        col = GetComponent<Collider2D>();
        gameController = FindObjectOfType<GameController>();

        if (gameController == null)
        {
            Debug.Log("GameController not found.");
        }

        target.x = Random.Range(walkableRange.x, walkableRange.y);
        target.y = transform.position.y;
        //Debug.Log(target);
        generatedWaitTime = Random.Range(waitTimeRange.x, waitTimeRange.y);
        startColOffset = col.offset;

        SetDirection();
    }

    private void Update()
    {
        if (isScared == true)
        {
            if (transform.position != target)
            {
                transform.position = Vector3.MoveTowards(transform.position, target, movementSpeed * 3 * Time.deltaTime);
                return;
            }
            else
            {
                //Debug.Log(gameObject.name + " has despawned.");
                gameController.OnPeopleExit(fearSlider.value);
                Destroy(gameObject);
            }
        }

        if (transform.position != target && isScared == false)
        {
            transform.position = Vector3.MoveTowards(transform.position, target, movementSpeed * Time.deltaTime);
            //Debug.Log("Moving");
        }
        else if (waitedTime < generatedWaitTime)
        {
            anim.SetFloat("Speed", 0f);
            waitedTime += Time.deltaTime;
            //Debug.Log("Waiting");
        }
        else
        {
            generatedIncrement = Random.Range(distanceIncrement.x, distanceIncrement.y);
            target.x += generatedIncrement;
            generatedWaitTime = Random.Range(waitTimeRange.x / 2, waitTimeRange.y / 2);
            waitedTime = 0f;
            SetDirection();
            //Debug.Log("Generating");
        }

        fearSlider.value += fearRate * Time.deltaTime;
    }

    void SetDirection()
    {
        if (transform.position.x < target.x)
        {
            dir = Direction.Right;
            anim.SetFloat("Speed", 1f);
            col.offset = startColOffset;
        }
        else if (transform.position.x >= target.x)
        {
            dir = Direction.Left;
            anim.SetFloat("Speed", -1f);
            col.offset = new Vector2(-startColOffset.x, startColOffset.y);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (isScared == false)
        {
            //Debug.Log(gameObject.name + " collided with player");

            GameObject obj = Instantiate(exclamationMarkIcon, exclamationMarkPos);
            isScared = true;

            if (transform.position.x < collision.transform.position.x)
            {
                target.x = walkableRange.x - 5f;
                //Debug.Log(target);
            }
            else
            {
                target.x = walkableRange.y + 5f;
                //Debug.Log(target);
            }

            SetDirection();
            //Debug.Log(dir);

            if (dir == Direction.Left)
            {
                obj.GetComponent<SpriteRenderer>().flipX = true;
            }
        }
    }
}
