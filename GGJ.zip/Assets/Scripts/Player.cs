﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float movementSpeed;
    public Animator anim;

    Rigidbody2D rb;
    Vector2 movementInput;
    Collider2D col;
    bool isHiding;

    private void Start()
    {
        col = GetComponent<Collider2D>();
        rb = GetComponent<Rigidbody2D>();
        movementInput.y = 0f;
    }

    private void Update()
    {
        if (isHiding == false)
        {
            movementInput.x = Input.GetAxisRaw("Horizontal");
            anim.SetFloat("Speed", movementInput.x);
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            anim.SetBool("isHiding", true);
            col.enabled = false;
            isHiding = true;
            movementInput.x = 0f;
        }
        else if (Input.GetKeyUp(KeyCode.Space))
        {
            anim.SetBool("isHiding", false);
            col.enabled = true;
            isHiding = false;
        }
    }

    private void FixedUpdate()
    {
        Vector2 target = rb.position + movementInput * movementSpeed * Time.deltaTime;
        target.x = Mathf.Clamp(target.x, -39f, 39f);
        rb.MovePosition(target);
    }
}
