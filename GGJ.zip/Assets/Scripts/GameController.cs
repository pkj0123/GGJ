﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameController : MonoBehaviour
{
    public Vector2 reputationRange;
    public Text repText;

    Reputation rep;
    float fear;

    enum Reputation
    {
        Nice,
        Normal,
        Haunted
    }

    private void Start()
    {
        SetReputation();
    }

    public void OnPeopleExit(float fearValue)
    {
        fear += fearValue;
        SetReputation();
    }

    void SetReputation()
    {
        if (fear < reputationRange.x)
        {
            rep = Reputation.Nice;
            repText.text = "Reputation: Nice Park";
        }
        else if (fear >= reputationRange.x && fear <= reputationRange.y)
        {
            rep = Reputation.Normal;
            repText.text = "Reputation: Normal Park";
        }
        else if (fear > reputationRange.y)
        {
            rep = Reputation.Haunted;
            repText.text = "Reputation: Haunted Park";
        }
    }
}
