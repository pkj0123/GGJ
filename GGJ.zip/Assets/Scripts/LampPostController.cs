﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LampPostController : MonoBehaviour
{
    public float lifespan;
    public Animator anim;

    float curLifetime;

    private void Start()
    {
        Recharge();
    }

    private void Update()
    {
        curLifetime -= Time.deltaTime;
        anim.SetFloat("lifetime", curLifetime);
    }

    public void Recharge()
    {
        curLifetime = lifespan;
    }
}
